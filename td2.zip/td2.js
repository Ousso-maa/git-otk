function Generer(){
    //var prenom = prompt("Entrer votre prenom").toLowerCase();

    //var nom = prompt("Entrer votre nom").toLowerCase();
    var prenomLabel = document.querySelector('label[for="prenom"]');
    var nomLabel = document.querySelector('label[for="nom"]');
    var emailLabel = document.querySelector('label[for="email"]');

    var prenom = document.getElementById("prenom").value;

    var nom =document.getElementById("nom").value;

    var lowercaseprenom = prenom.toLowerCase();
    var lowercasenom = nom.toLowerCase();

    var date = new Date();

    var email = lowercaseprenom.charAt(0) + lowercasenom +date.getFullYear() +"@otkSupinfo.com";
    document.getElementById("email").value = email;

    prenomLabel.classList.add("couleur_vert");
    nomLabel.classList.add("couleur_vert");
    emailLabel.classList.add("couleur_vert");
}